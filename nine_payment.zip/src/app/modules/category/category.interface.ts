export type TCategory = {
    name: string;
    isDeleted: boolean;
}