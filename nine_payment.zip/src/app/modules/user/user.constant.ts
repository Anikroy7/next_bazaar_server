export const USER_ROLE = {
  cutomer: "customer",
  admin: "admin",
} as const;
