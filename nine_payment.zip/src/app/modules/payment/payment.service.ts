import { prisma } from "../../types/global"

const caretePaymentIntoDB = async (payload: any) => {
    /* const payment = await prisma.payment.create({
        data: {
            orderId: payload.
    }
    }) */

}

export const PaymentServices = {
    caretePaymentIntoDB
}